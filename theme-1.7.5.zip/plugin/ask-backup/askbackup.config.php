<?php

/**
 * ASK Backup 1.0.0
 * 유료 프로그램입니다. 불법복제 금지
 */
ini_set('memory_limit', '256M');
set_time_limit(0);
ignore_user_abort(true);

//백업 저장 경로
define('ASK_BACKUP_DIR', G5_DATA_PATH);