<?php
/**
 * ASK MetaTag Generator 
 * 유료 프로그램입니다. 불법복제 금지
 */

include_once '../../common.php';
