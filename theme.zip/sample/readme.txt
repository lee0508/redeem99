Theme Name: 티로그A
Theme URI: http://gaya.tlog.kr/demo/tlog_a
Maker: TLOG
Maker URI: http://tlog.kr
Version: 0.0.1
Detail: 티로그A 테마는  TLOG에서 제공하는 그누보드5 테마입니다 티로그A 테마는 웹표준 및 접근성을 준수합니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html