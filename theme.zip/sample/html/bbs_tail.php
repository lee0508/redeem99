        </div><!--txtCon-->
    </section><!--content subContent-->
</div>
<?php
include_once(G5_THEME_PATH.'/tail.php');
?>