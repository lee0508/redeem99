<div id="mail_bpopup_form" style="display:none;">
    <div style="position:relative; max-width:853px; height:500px; margin:auto;"> <span class="button b-close" style="position:absolute; top:50px; right:25px;">
        <button title="Close (Esc)" type="button" class="mfp-close">×</button>
        </span>
        <div style="padding-top:30px;">
            <div class="tl_pop_con">
                <div class="f_pop_wrap">
                    <h2 class="f_pop_tit"><span>이메일무단수집거부</span></h2>
                    <strong>
                    <p>
                        ① 본 웹사이트에 게시된 이메일 주소가 전자우편 수집 프로그램이나 그 밖의 기술적 장치를 이용하여 무단으로 수집되는 것을 거부하며, 이를 위반시 정보통신망법에 의해 형사처벌됨을 유념하시기 바랍니다. </strong><br>
                        ② 정보통신망법 제 50조의 2 (전자우편주소의 무단 수집행위 등 금지)<br>
                        누구든지 전자우편주소의 수집을 거부하는 의사가 명시된 인터넷 홈페이지 에서 자동으로 전자우편주소를 수집하는 프로그램 그 밖의 기술적 장치를 이용하여 전자우편주소를 수집하여서는 아니된다.<br>
                        ③ 누구든지 제1항의 규정을 위반하여 수집된 전자우편주소를 판매·유통하여서는 아니된다.<br>
                        ④ 누구든지 제1항 및 제2항의 규정에 의하여 수집·판매 및 유통이 금지된 전자 우편주소임을 알고 이를 정보전송에 이용하여서는 아니된다. 
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>