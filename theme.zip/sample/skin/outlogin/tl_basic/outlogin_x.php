<?php
include './_common.php';
include_once './outlogin.lib.php';
echo outlogin_x($OUTLOGIN_SKIN_DIR);
?>